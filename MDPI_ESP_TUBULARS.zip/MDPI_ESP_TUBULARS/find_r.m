%% SOLVE CABLE POSITION
% This code is employed to find the ESP location within body coordinates
% frame r, its derivative dr/ds, and its second derivative d2r/ds2
function [r,dr,d2r] = find_r(p_pre,R_pre,target,diam,rend,number_rho,number_theta)  
global sstart C no_disc may_point ss;
point_current = [];
start_point = sstart;

        theta = 0:2*pi/number_theta:2*pi-2*pi/number_theta;
        rho = 0:diam/(2*number_rho):(diam/2);
        
%% INITIALISATION
no_disc = 1;                                                        % Examined Disc
may_point = [R_pre{no_disc} p_pre(:,no_disc+1); 0 0 0 1]*sstart;    % Examined Point
dis1 = sqrt((may_point(1)-p_pre(1,no_disc+1))^2+(may_point(2)-p_pre(2,no_disc+1))^2+(may_point(3)-p_pre(3,no_disc+1))^2);  % Distance to the center-curve        
C = location_X(may_point,dis1,p_pre(:,no_disc+1),R_pre{no_disc},rho,theta); % Four Boudary-Points (mesh) around the Examined Point   
%% SOLVER
Need_check_2 = 1;
for i = 1:length(R_pre)
    %% CHECK PARTITION 1
        k_tmp = 0;
        for k = i:length(R_pre)-1
            [~,distance_test] = findX(R_pre{k}(1,3),R_pre{k}(2,3),R_pre{k}(3,3),p_pre(:,k+1),target,start_point);
            if distance_test <= diam(1,1)/2
                k_tmp = k_tmp+1;
            end
        end
        % PARTITION 1 true
	if k_tmp==length(R_pre)-i 
            for t = 1:length(R_pre)-i
                [sX,~] = findX(R_pre{i+t-1}(1,3),R_pre{i+t-1}(2,3),R_pre{i+t-1}(3,3),p_pre(:,i+t),target,start_point);
                point_current = [point_current [sX(1); sX(2); sX(3); 1]];
            end
            break; % do not need to check PARTITIONs 2 and 3
    else    
        
	%% CHECK PARTITION 2
        if Need_check_2
            Is_Partition2 = 0; alpha = 10000;        
            for nn = 1:length(rho)
                for mm = 1:length(theta)-1
                    tmp_end = [R_pre{end} p_pre(:,end); 0 0 0 1]*[rho(nn)*cos(theta(mm));rho(nn)*sin(theta(mm));0;1]; % examine one point in Segment end
                    num_visible_disc = 0; num_max = 0; 
                    for j = i:length(R_pre)-1
                        [X,dis] = findX(R_pre{j}(1,3),R_pre{j}(2,3),R_pre{j}(3,3),p_pre(:,j+1),tmp_end,start_point);
                        if (dis<=diam(1,1)/2)
                            num_visible_disc = num_visible_disc+1;
                            if j==i
                                tmp = [X;1];
                            end
                        else
                            break;
                        end
                    end
                    if num_visible_disc == length(R_pre)-i  % start_point can see tmp_end
                        Is_Partition2 = 1;                  % PARTITION 2 true
                        u = tmp_end(1:3)-start_point(1:3);
                        v = target(1:3)-start_point(1:3);
                        Cos_angle = dot(u,v)/(norm(u)*norm(v));
                        alpha_tmp = acos(Cos_angle);
                        if alpha > alpha_tmp
                            alpha = alpha_tmp;
                            point_current(:,i) = tmp;
                        end
                    else                                    % start_point cannot see tmp_end
                        if num_max < num_visible_disc
                            num_max = num_visible_disc;
                            no_disc = i+num_max-1; % prepare a faraway examined disc for PARTITION 3, the index is correspondant with R 
                            [X1,dis1]  = findX(R_pre{no_disc}(1,3),R_pre{no_disc}(2,3),R_pre{no_disc}(3,3),p_pre(:,no_disc+1),tmp_end,start_point);
                            may_point = [X1;1];    % prepare a faraway examined point for PARTITION 3,
                        end
                    end
                end
            end
        end
    
	%% CHECK PARTITION 3   
        if Is_Partition2 == 0   % PARTITION 2 false        
            if num_max>1 % there is something prepared from PARTITION 2
                    % Find the vicinity area of may_point
                    C = location_X(may_point,dis1,p_pre(:,no_disc+1),R_pre{no_disc},rho,theta); % Set of investigating points  
                    point_current(:,i) = oriented_drill(i,R_pre,p_pre,start_point,number_rho,number_theta,rho,theta,diam);  
            else        % there is nothing prepared from PARTITION 2 -> Do it at the begining
                    [~,dis1]  = findX(R_pre{no_disc}(1,3),R_pre{no_disc}(2,3),R_pre{no_disc}(3,3),p_pre(:,no_disc+1),may_point,start_point);
                    C = location_X(may_point,dis1,p_pre(:,no_disc+1),R_pre{no_disc},rho,theta);               
                    point_current(:,i) = oriented_drill(i,R_pre,p_pre,start_point,number_rho,number_theta,rho,theta,diam);
            end
        end
    %% Update the new start_point
        start_point = point_current(:,i);
	end
end

for i = 1:length(point_current)
    ptest = [R_pre{i} p_pre(:,i+1); 0 0 0 1]\point_current(:,i);
    x(i)  = ptest(1);
    y(i)  = ptest(2);
    z(i)  = 0;
end

% Delete the ripple
r_n = [x; y; z];
r_new = [sstart(1:3) r_n rend(1:3)];


r = r_new;

dr(:,1) = (ss)*(r(:,2)-r(:,1));

d2r = zeros(3,length(r));

for i = 2:length(r)-1
    dr(:,i) = (ss/2)*(r(:,i+1)-r(:,i-1));
    d2r(:,i) = (r(:,i+1)-2*r(:,i)+r(:,i-1))*(ss)^2;
end
dr = [dr dr(:,end)];
d2r(:,end) = d2r(:,end-1);
end


