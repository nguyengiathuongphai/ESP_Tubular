function Ce = extend_bound(A,B,number_pro,number_theta) 
	Ce = [];
        for mm = 1:size(A,1)
                C_tmp = [A(mm,1)-1 A(mm,2)-1; A(mm,1)-1 A(mm,2); A(mm,1)-1 A(mm,2)+1; ...
                         A(mm,1)+1 A(mm,2)-1; A(mm,1)+1 A(mm,2); A(mm,1)+1 A(mm,2)+1; ...
                         A(mm,1) A(mm,2)-1; A(mm,1) A(mm,2)+1];
                %filter for C_tmp to obtain C_fil without the outside-tube points
                ij = 0; C_fil = [];
                for nn = 1:size(C_tmp,1)
                    if C_tmp(nn,2)<1 || C_tmp(nn,2)>number_theta
                        id = mod(C_tmp(nn,2),number_theta);
                        if id == 0
                            id = number_theta;
                        end
                        C_tmp(nn-ij,2) = id;
                    end
                    if C_tmp(nn,1)>0 && C_tmp(nn,1)<=number_pro
                        C_fil = [C_fil; C_tmp(nn,:)];
                    end
                end            
                                
                for nn = 1:size(C_fil,1)
                    num = 0;
                    for k = 1:size(B,1)
                        if and((C_fil(nn,1)==B(k,1)),(C_fil(nn,2)==B(k,2)))
                            num = 1;
                        end
                    end
                    if num==0
                        Ce = [Ce; C_fil(nn,:)];
                    end
% % % % %                     tes = (Cc(nn,:)==B);
% % % % %                     if sum(prod(tes'))>0
% % % % %                         continue;
% % % % %                     else
% % % % %                         Ce = [Ce; Cc(nn,:)];
% % % % %                     end
                end
        end
    if ~isempty(Ce)
        [Ce,~,~] = unique(Ce(:,1:2),'rows');
    end
end