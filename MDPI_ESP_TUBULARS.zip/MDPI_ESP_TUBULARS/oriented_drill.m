function point = oriented_drill(ii,R_pre,p_pre,start_point,number_pro,number_theta,rho,theta,diam)
global C no_disc may_point;
                A = [];     % Set of extendable points
                B = [];     % Set of investigated points
                leng_ma = 0;
while (~isempty(C))  
    flag = 0;               % not Find a new deeper section (Initial value)
    for k = 1:size(C,1) 
        tmp = [R_pre{no_disc} p_pre(:,no_disc+1); 0 0 0 1]*[rho(C(k,1))*cos(theta(C(k,2)));rho(C(k,1))*sin(theta(C(k,2)));0;1]; % Examined Point                 
        num=0;  
        for j = ii:length(R_pre)-1                    
            [~,dis] = findX(R_pre{j}(1,3),R_pre{j}(2,3),R_pre{j}(3,3),p_pre(:,j+1),tmp,start_point);                   
            if (dis<=diam(1,1)/2)                           
                num = num+1;                       
            else               
                break;
            end
        end
                
        if num > no_disc-ii+1                                              % Drill deeper  
            no_disc = num+ii-1;        
            [X1,dis1]  = findX(R_pre{no_disc}(1,3),R_pre{no_disc}(2,3),R_pre{no_disc}(3,3),p_pre(:,no_disc+1),tmp,start_point);      
            may_point = [X1;1];      
            C = location_X(may_point,dis1,p_pre(:,no_disc+1),R_pre{no_disc},rho,theta);           
            A = [];           
            B = [];          
            flag = 1;       % Find a new deeper section                      
            break;       
        elseif num == no_disc-ii+1                                         % Drill to just the same disc      
            A = [A; C(k,:)];            
            B = [B; C(k,:)];          
        else                                                               % Cannot see this investigating point 
            B = [B; C(k,:)];           
        end     
    end   
    if flag == 0  
        % Extend boundary      
        C = extend_bound(A,B,number_pro,number_theta);        
        if (~isempty(C))
            A = [];
        else           
            continue;           
        end        
    end    
end

if isempty(A)
    [X,~] = findX(R_pre{ii}(1,3),R_pre{ii}(2,3),R_pre{ii}(3,3),p_pre(:,ii+1),may_point,start_point);   
    point = [X;1];   
else    
    for j = 1:size(A,1)   
        tmp = [R_pre{no_disc} p_pre(:,no_disc+1); 0 0 0 1]*[rho(A(j,1))*cos(theta(A(j,2)));rho(A(j,1))*sin(theta(A(j,2)));0;1];       
        leng_tmp = sqrt((tmp(1)-start_point(1))^2+(tmp(2)-start_point(2))^2+(tmp(3)-start_point(3))^2);       
        if leng_ma < leng_tmp      
            leng_ma = leng_tmp;            
            [X,~] = findX(R_pre{ii}(1,3),R_pre{ii}(2,3),R_pre{ii}(3,3),p_pre(:,ii+1),may_point,start_point);           
            point = [X;1];           
        end       
    end   
end