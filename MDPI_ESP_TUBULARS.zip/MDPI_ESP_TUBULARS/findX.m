function [X,distance] = findX(A,B,C,p,waypoint,start_point)
% This function is to determine the intersection point X between the line
% segment from the start_point to the waypoint and the plane containing
% point p that have normal vertor (A,B,C)
format long;
    u = waypoint-start_point;
    X = zeros(3,1);
    num = u(1)*(A*p(1)+B*p(2)+C*p(3))+B*(u(2)*start_point(1)-u(1)*start_point(2))+C*(u(3)*start_point(1)-u(1)*start_point(3));
    den = A*u(1)+B*u(2)+C*u(3);
        X(1) = num/den;
        X(2) = (u(2)/u(1))*(X(1)-start_point(1))+start_point(2);
        X(3) = (u(3)/u(1))*(X(1)-start_point(1))+start_point(3);
        distance = sqrt((X(1)-p(1))^2+(X(2)-p(2))^2+(X(3)-p(3))^2);
end
    