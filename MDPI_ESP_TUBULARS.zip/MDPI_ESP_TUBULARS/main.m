clear all;
close all;
clc;

global ss D_in;
ss = 1/0.2;          
dl = 1/ss;      % dl = 0.2 (cm) is the discretized step (h in the Research Article)
D_in = 3;       % Inner Diameter of the tube (cm)

%% =====Generate an arbitrary tube with its center-curve and diameter=====
tic
%% ----------Equation of Tube Center Line----------
syms t;
    %% Multi-Segment of Constant Curvature
    % Except the complex shaped tube, all of the others have 30 (cm) in length
        % Tube 1: Right circular cylinder  
            x1 = t;
            y1 = 0;
            z1 = 0;
            t0 = 0;                 % modify the lower-boundary value of t to shift the starting point of the tube;
            t_end = 30;             % modify the upper-boundary number to have ds = dl = 0.2 cm for all sections; 
            tspan_1 = [t0 t_end];   
        	num1 = 150;             % number of section (num1 = 150, we have 30 cm tube)
        % Tube 2: Right circular cylinder+Two plane precurved6 tubes bending in opposite directions  
        a = 4; b = 17; Kappa1 = 1/5; Kappa2 = 1/4;       
        alpha1 = Kappa1*(t-a);
        alpha2 = Kappa2*(t-b);
        alpha1_t = (b-a)*Kappa1;
        alpha2_0 = pi/2-alpha1_t;
        y2_1 = (1-cos(alpha1))/Kappa1;
        y2_2 = (1-cos(alpha1_t))/Kappa1+(sin(alpha2+alpha2_0)-sin(alpha2_0))/Kappa2;
        z2_1 = a+sin(alpha1)/Kappa1;
        z2_2 = a+sin(alpha1_t)/Kappa1+(cos(alpha2_0)-cos(alpha2+alpha2_0))/Kappa2;
            x2 = 0;
            y2 = piecewise(t<a, 0, a<=t<=b, y2_1, y2_2);
            z2 = piecewise(t<a, t, a<=t<=b, z2_1, z2_2);
            t_end = 30;             % modify the upper-boundary number to have ds = dl = 0.2 cm for all sections;
            tspan_2 = [t0 t_end];   
        	num2 = 150;             % number of section (num1 = 150, we have 30 cm tube)
        % Tube 3: Right circular cylinder+Two precurved tubes bending in different directions in space 
        a = 4; b = 17; Kappa1 = 1/6; Kappa2 = 1/4; 
        alpha1 = Kappa1*(t-a);
        alpha2 = Kappa2*(t-b);
        alpha1_t = (b-a)*Kappa1;
        y2_1 = (1-cos(alpha1))/Kappa1;
        z2_1 = a+sin(alpha1)/Kappa1;
        R_1t = [1 0 0; 0 cos(alpha1_t) sin(alpha1_t); 0 -sin(alpha1_t) cos(alpha1_t)];
        p_1t = [0; (1-cos(alpha1_t))/Kappa1; sin(alpha1_t)/Kappa1];
        R2   = [cos(alpha2) 0 sin(alpha2); 0 1 0; -sin(alpha2) 0 cos(alpha2)];
        p2   = [(1-cos(alpha2))/Kappa2; 0; sin(alpha2)/Kappa2];
        A = [1 0 0 0; 0 1 0 0; 0 0 1 4; 0 0 0 1]*[[R_1t p_1t]; [0 0 0 1]]*[[R2 p2]; [0 0 0 1]]*[0;0;0;1];
        x2_2 = A(1);
        y2_2 = A(2); 
        z2_2 = A(3);
            x3 = piecewise(t<a, 0, a<=t<=b, 0, x2_2);
            y3 = piecewise(t<a, 0, a<=t<=b, y2_1, y2_2);
            z3 = piecewise(t<a, t, a<=t<=b, z2_1, z2_2);
            t_end = 30;             % modify the upper-boundary number to have ds = dl = 0.2 cm for all sections (see Line 169);
            tspan_3 = [t0 t_end]; 
        	num3 = 150;             % number of section (num1 = 150, we have 30 cm tube)
    %% Center-line curve in plane
        % Tube 4: Tubular surface with a plane parabolic centerline
            x4 = t;
            y4 = 0.1*t^2;
            z4 = 0;
            t0 = -10;               % modify the lower-boundary value of t to shift the starting point of the tube;
            t_end = 10;             % modify the upper-boundary number to have ds = dl = 0.2 cm for all sections;
            tspan_4 = [t0 t_end]; 
            num4 = 150;             % number of section (num1 = 150, we have 30 cm tube)
        % Tube 5: Tubular surface with a plane elliptical centerline
            a  = 7; b = 9; 
            x5 = a*cos(t);
            y5 = b*sin(t);
            z5 = 0;
            t0 = 0;                 % modify the lower-boundary value of t to shift the starting point of the tube;
            t_end = 3.7;            % modify the upper-boundary number to have ds = dl = 0.2 cm for all sections (see Line 169);
            tspan_5 = [t0 t_end];     
            num5 = 150;             % number of section (num1 = 150, we have 30 cm tube)
        % Tube 6: Tubular surface with a plane hyperbolic centerline
            a  = 7; b = 6; 
            x6 = a*cosh(t);
            y6 = b*sinh(t);
            z6 = 0;        
            t0 = -1.5;              % modify the lower-boundary value of t to shift the starting point of the tube;
            t_end = 1.38;           % modify the upper-boundary number to have ds = dl = 0.2 cm for all sections (see Line 169);
            tspan_6 = [t0 t_end]; 
            num6 = 150;             % number of section (num1 = 150, we have 30 cm tube)
        % Tube 7: Tubular surface with a plane sinusoidal centerline
            a  = 3.5; b = 0.4; 
            x7 = t;
            y7 = a*sin(b*t);
            z7 = 0;        
            t0 = 0;                 % modify the lower-boundary value of t to shift the starting point of the tube;
            t_end = 22;             % modify the upper-boundary number to have ds = dl = 0.2 cm for all sections (see Line 169);
            tspan_7 = [t0 t_end]; 
            num7 = 150;             % number of section (num1 = 150, we have 30 cm tube)
%         % Tube 8: Tubular surface with a plane cycloid centerline
%             a  = 3.5;
%             x8 = a*(cos(t)+t*sin(t));
%             y8 = a*(sin(t)-t*cos(t));
%             z8 = 0;        
%             t0 = 0;               % modify the lower-boundary value of t to shift the starting point of the tube;
%             t_end = 4.14;         % modify the upper-boundary number to have ds = dl = 0.2 cm for all sections (see Line 169);
%             tspan_8 = [t0 t_end]; 
%             num8 = 150;           % number of section (num1 = 150, we have 30 cm tube)
        % Tube 9: Tubular surface with a plane centerline in the form of the evolvent of a circle
            a  = 0.5; b = 0.1;
            x9 = a*(cos(t))-a*(b-t)*sin(t);
            y9 = a*(sin(t))+a*(b-t)*cos(t);
            z9 = 0;        
            t0 = 3;                 % modify the lower-boundary value of t to shift the starting point of the tube;
            t_end = 11.47;          % modify the upper-boundary number to have ds = dl = 0.2 cm for all sections (see Line 169);
            tspan_9 = [t0 t_end];    
            num9 = 150;             % number of section (num1 = 150, we have 30 cm tube)
    %% Center-line curve in space
        % Tube 10: Tubular helical surface
            a  = 2.5; b = 1.5;
            x10 = a*cos(t);
            y10 = a*sin(t);
            z10 = b*t;        
            t0 = 3;                 % modify the lower-boundary value of t to shift the starting point of the tube;
            t_end = 13.29;          % modify the upper-boundary number to have ds = dl = 0.2 cm for all sections (see Line 169);
            tspan_10 = [t0 t_end];  
            num10 = 150;            % number of section (num1 = 150, we have 30 cm tube)
        % Tube 11:  Tubular spiral surface
            a  = 1; b = 0.12; c = 3;
            x11 = a*exp(b*t)*cos(t);
            y11 = a*exp(b*t)*sin(t);
            z11 = a*exp(b*t)*c;        
            t0 = pi;                % modify the lower-boundary value of t to shift the starting point of the tube;
            t_end = 13.1;           % modify the upper-boundary number to have ds = dl = 0.2 cm for all sections (see Line 169);
            tspan_11 = [t0 t_end];  
            num11 = 150;            % number of section (num1 = 150, we have 30 cm tube)    
%         % Tube 12:  Tubular loxodrome
%             a  = 6; b = 0.15; c = 0.1*pi;
%             x12 = a*cos(t)/cosh(b*(t-c));
%             y12 = a*sin(t)/cosh(b*(t-c));
%             z12 = a*tanh(b*(t-c));        
%             t0 = -3*pi;           % modify the lower-boundary value of t to shift the starting point of the tube;
%             t_end = 10;           % modify the upper-boundary number to have ds = dl = 0.2 cm for all sections (see Line 169);
%             tspan_12 = [t0 t_end];
%             num12 = 450;          % number of section (num1 = 450, we have 90 cm tube)
        % Tube 13:  Tubular surface of a wave-shaped torus on the sphere
            a  = 5; b = 0*pi/2; c = 0.1*pi/2; d = 3;
            w = b+c*sin(d*t);
            x13 = a*cos(t)*cos(w);
            y13 = a*sin(t)*cos(w);
            z13 = a*sin(w);        
            t0 = -3;                % modify the lower-boundary value of t to shift the starting point of the tube;
            t_end = 2.72;           % modify the upper-boundary number to have ds = dl = 0.2 cm for all sections (see Line 169);
            tspan_13 = [t0 t_end];  
            num13 = 150;            % number of section (num1 = 150, we have 30 cm tube)
            
    %% Complex
            % Tube 14:  Tubular surface of a wave-shaped torus on the sphere
            x14 = 20*log(t)*sin(t)*cos(0.4*t^2);
            y14 = 25*sqrt(t)*cos(1.2*abs(t-2));
            z14 = 13*abs((log(t)-sqrt(t)));        
            t0 = 0.1;               % modify the lower-boundary value of t to shift the starting point of the tube;
            t_end = 3.53;           % modify the upper-boundary number to have ds = dl = 0.2 cm for all sections (see Line 169);
            tspan_14 = [t0 t_end];  
            num14 = 600;            % number of section (num1 = 600, we have 120 cm tube)

%% -------------------Create the tubes--------------------
% Choose Tube Parameters
x = x5;             % In order to choose Tube i, x = xi where i = {1,2,3...}
y = y5;             % In order to choose Tube i, y = yi where i = {1,2,3...}
z = z5;             % In order to choose Tube i, z = zi where i = {1,2,3...}
tspan = tspan_5;    % In order to choose Tube i, tspan = tspan_i where i = {1,2,3...}
num = num5;         % In order to choose Tube i, num = numi where i = {1,2,3...}   
% Create Tube
ds = simplify(sqrt((diff(x,t))^2+(diff(y,t))^2+(diff(z,t))^2));     % Finding Arclength element ds as a function of parameter t
F = matlabFunction(ds, 'vars',{'t','s'});
s0 = 0;
[t_tmp,s_tmp] = ode45(F, tspan, s0);

t_var = zeros(1,num+1);
for i = 1:num+1
    t_var(i) = piecelin(s_tmp,t_tmp,(i-1)*dl);                      % Refind t_var corresponding a series of equally spaced points (x_var,y_var,z_var) (arclength distance ds = 0.2cm) along the centerline 
end


for i = 1:length(t_var)
    x_var(i) = double(simplify(subs(x,t,t_var(i))));
    y_var(i) = double(simplify(subs(y,t,t_var(i))));
    z_var(i) = double(simplify(subs(z,t,t_var(i))));
end

pp = double([x_var' y_var' z_var']');                               % The Centerline consists of the equidistant points



%% Choose parameters
r_start = [0; 0; 0];                % Location of the Source within cross-section S0
r_end   = [0; 0; 0];                % Location of the Destination within cross-section S_{n+1}

%% Meshing the cross-section
N_rho = 25;                         % Number of concentric circles used for Dijkstra's algorithm
N_theta = 4;                        % Number of arcs on a (concentric) circle used for Dijkstra's algorithm

Generating_Tube_Time = toc;         % Display time required to generate the Tube
   

%% SOLVER for Proposed Algor, Dijkstra's Algor, and Exact Solu
[Tendon_proposed, Tendon_Dijkstra, L_propose, L_Dijkstra] = Compare_Two_Med(pp, r_start, r_end, N_rho, N_theta);
disp('-------------------------------------------');
if s_tmp(end)<num*0.2-0.5
    disp(['Need to increase t_end to have the final value is about ' num2str(num*0.2) '.0...']);
elseif s_tmp(end)>num*0.2+0.5
    disp(['Need to decrease t_end to have the final value is about ' num2str(num*0.2) '.0...']);
end
