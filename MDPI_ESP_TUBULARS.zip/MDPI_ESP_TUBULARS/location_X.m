function Four_Points = location_X(may_point,dis1,p_no,R_no,rho,theta)   
global D_in;

Delta_rho   = rho(2);
Delta_theta = theta(2);

u    = may_point(1:3) - p_no;                                              % defining vector of may_point on the disc
ttmp = [R_no p_no; 0 0 0 1]*[(D_in/2)*cos(0);(D_in/2)*sin(0);0;1];         % reference point on the disc
v    = ttmp(1:3) - p_no;                                                   % reference vector on the disc
CosTheta = dot(u,v)/(norm(u)*norm(v));

if CosTheta<-1
    CosTheta = -1; % Calculation error of MATLAB. ex, -1.000000003
elseif CosTheta>1
    CosTheta = 1;  % Calculation error of MATLAB. ex, 1.000000003
end
ThetaInRad  = acos(CosTheta);                                              % angle of may_point versus the reference vector on the disc
if cross(v,u) ~= 0
    if R_no(:,3)'*cross(v,u)<0
        ThetaInRad = 2*pi-ThetaInRad;
    end
end

    k_rho = [floor(dis1/Delta_rho)+1 floor(dis1/Delta_rho)+2];
    if floor(dis1/Delta_rho) == length(rho)-1
        k_rho = [length(rho)-1 length(rho)];
    end
    k_theta = [floor(ThetaInRad/Delta_theta)+1 floor(ThetaInRad/Delta_theta)+2];
    if floor(ThetaInRad/Delta_theta) >= length(theta)-1
        k_theta = [length(theta) 1];
    end
    
Four_Points = [k_rho(1) k_theta(1); k_rho(1) k_theta(2); k_rho(2) k_theta(1); k_rho(2) k_theta(2)];