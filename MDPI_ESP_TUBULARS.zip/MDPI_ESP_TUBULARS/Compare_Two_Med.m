function [Tendon_proposed, Tendon_Dijkstra, L_propose, L_Dijkstra] = Compare_Two_Med(p_pre, r_start, r_end, N_rho, N_theta)
global D_in sstart;
figure(1)
size = 24;
[TT,NN,BB,~,~] = frenet(p_pre(1,:),p_pre(2,:),p_pre(3,:));              % Generate the coordinate frame
% Find the orientation matrix
for i=1:length(p_pre(1,:))-1
    if and(NN(i,:) == [0 0 0], BB(i,:) == [0 0 0])                      % case of straight line
        R_pre{i} = eye(3);                                              % add this to have Tube 1 in horizon
    else
        R_pre{i} = [NN(i+1,:)' BB(i+1,:)' TT(i+1,:)'];
    end
end
    
    
    %% PARAMETERS OF SETTING
target  = [[R_pre{end} p_pre(:,end)]; 0 0 0 1]*[r_end; 1];              % Destination point in global frame
if and(NN(1,:) == [0 0 0], BB(1,:) == [0 0 0])                          % case of straight line
    sstart  = [r_start; 1];
else
    sstart  = [[NN(1,:)' BB(1,:)' TT(1,:)'] [p_pre(1,1); p_pre(2,1); p_pre(3,1)]; 0 0 0 1]*[r_start; 1];
end

%% Plots the Tube
    q          = linspace(0,2*pi,100);
    base_o     = (D_in/2)*[cos(q); sin(q)];
    [X,Y,Z] = extrude(base_o,p_pre);
    surface_o  = surf(X,Y,Z);  hold on; axis equal; grid on;
    set(surface_o,'FaceColor','g','FaceAlpha',.4,'EdgeColor','none');
	plot3(sstart(1),sstart(2),sstart(3),'.g','MarkerSize',20); 
    plot3(target(1),target(2),target(3),'.g','MarkerSize',20);  
    xlabel('x (cm)','FontSize', size); ylabel('y (cm)','FontSize', size); zlabel('z (cm)','FontSize', size); 
    a_plot = plot3(p_pre(1,:),p_pre(2,:),p_pre(3,:),'.y','MarkerSize',3); 
    pause(0.1);

    
    
    
    
%% Proposed Solver  
disp('Start the Proposed Method');
tic
% Finding the location of the ESP within the cross-section
[r_body] = find_r(p_pre,R_pre,target,D_in,r_end,N_rho,N_theta);
r_glob = zeros(4,length(r_body));
r_glob(:,1) = sstart;
for i = 2:length(r_body)
    vs = [[R_pre{i-1} p_pre(:,i)]; 0 0 0 1]*[r_body(:,i); 1];
    r_glob(:,i) = vs;    
end
My_calcul = toc;
disp('Finish the Proposed Method');
L_propose = 0;
for i=1:length(r_glob)-1
    L_propose = L_propose+norm(r_glob(1:3,i+1)-r_glob(1:3,i));
end 

% plots
b_plot = plot3(r_glob(1,:),r_glob(2,:),r_glob(3,:),'r','LineWidth',4); 
pause(0.1);


%% Dijkstra's algorithm
disp('Start Dijkstra Method');
tic;
theta = 0:2*pi/N_theta:2*pi-2*pi/N_theta; rho = 0:D_in/(2*(N_rho-1)):(D_in/2);
 
% Meshing
for i = 1:length(R_pre)-1
    for u = 1:length(theta)
        for v = 1:length(rho)
            point_D{i,u,v}    = [R_pre{i} p_pre(:,i+1); 0 0 0 1]*[rho(v)*cos(theta(u));rho(v)*sin(theta(u));0;1];
        end
    end
end

% Solving
i = 1;
for u = 1:length(theta)
    for v = 1:length(rho)
        temp_point{u,v} = point_D{i,u,v};
        min_D(u,v)      = sqrt((point_D{i,u,v}(1)-sstart(1))^2+(point_D{i,u,v}(2)-sstart(2))^2+(point_D{i,u,v}(3)-sstart(3))^2);
    end
end

for i = 2:length(R_pre)-1
    temp_point_pre = temp_point;
    min_D_pre      = min_D;
    clear min_D;
    clear temp_point;
    for m = 1:length(theta)
        for n = 1:length(rho)
            min_D(m,n) = 100^5;
            for u = 1:length(theta)
            	for v = 1:length(rho)
                    ww = norm([point_D{i,m,n}(1:3)-point_D{i-1,u,v}(1:3)]);
                    if min_D(m,n) > min_D_pre(u,v)+ww
                    	min_D(m,n) = min_D_pre(u,v)+ww;
                        temp_point{m,n} = [temp_point_pre{u,v} point_D{i,m,n}];
                    end                    
            	end
            end 
        end    
    end
end
i = length(R_pre);
leng = 100^5;
    temp_point_pre = temp_point;
    min_D_pre      = min_D;
for u = 1:length(theta)
    for v = 1:length(rho)
    ww = norm(target(1:3)-point_D{i-1,u,v}(1:3));
    if leng > min_D_pre(u,v)+ww
            leng = min_D_pre(u,v)+ww;
            set_points = [temp_point_pre{u,v} target];
    end
    end
end
set_points = [sstart set_points];
L_Dijkstra = 0;
for i=1:length(set_points)-1
    L_Dijkstra = L_Dijkstra+norm(set_points(1:3,i+1)-set_points(1:3,i));
end 
Dijkstra_calcul = toc;
disp('Finish Dijkstra Method');

% Plot    
c_plot = plot3(set_points(1,:), set_points(2,:), set_points(3,:),'k', 'LineWidth', 4); 


% Resize the grid to clarify the inner tube zone
Number_reduce = 5; % Resize the tube if neccesary
for k = 1:(length(R_pre)/Number_reduce)
    p(:,k) = p_pre(:,1+(k-1)*Number_reduce);
    R{k} = R_pre{k*Number_reduce};
end
p(:,(length(R_pre)/Number_reduce)+1) = p_pre(:,end);

q          = linspace(0,2*pi,50);
base_o     = (D_in/2)*[cos(q); sin(q)];
[X,Y,Z]    = extrude(base_o,p);
surface_o  = surf(X,Y,Z);  hold on; axis equal; grid on;
set(surface_o,'FaceColor','none','EdgeAlpha',0.2);

legend([b_plot c_plot],'Proposed Method', 'Dijkstra"s Method', 'FontSize', size);










%% Results
    
L_norm = 0;
for i=1:length(p)-1
    L_norm = L_norm+sqrt((p(1,i)-p(1,i+1))^2+(p(2,i)-p(2,i+1))^2+(p(3,i)-p(3,i+1))^2);
end 

Tendon_proposed = r_glob;
Tendon_Dijkstra = set_points(1:3,:);


disp(['My_calcul = ', num2str(My_calcul) '(s)']);
disp(['Dijkstra_calcul = ', num2str(Dijkstra_calcul) '(s)']);

disp(['Tube length = ' num2str(L_norm) '(cm)']);
disp(['Tendon length (proposed) = ' num2str(L_propose) '(cm)']);
disp(['Tendon length (Dijkstra) = ' num2str(L_Dijkstra) '(cm)']);


